<body>
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="background-color:#c2c2d6; border-color:#c2c2d6;">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <img class="img-responsive" src="<?php echo base_url();?>assets/img/logo.png" alt="" style="width:170px; height:auto;">
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="" style="color:black; font-weight:bold; text-shadow:2px 2px 2px #ffffff, 4px 4px 3px #888888">HOME</a>
                    </li>
                    <li>
                        <a href="" style="color:black; font-weight:bold; text-shadow:2px 2px 2px #ffffff, 4px 4px 3px #888888">BLOG</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>