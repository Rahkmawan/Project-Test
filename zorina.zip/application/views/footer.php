			<footer style="margin:0px">
				<div class="row">
					<div class="col-lg-12">
						<p>By Akbar Rahkmawan Irianto</p>
					</div>
				</div>
			</footer>
		</div>
		<!-- Modal -->
		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-body">
						<h4 style="text-align:center; font-size:1.3em; color:#35514c; text-shadow:2px 2px 2px #ffffff, 4px 4px 3px #888888"><strong>Semoga saya diterima di perusahaan Bapak/Ibu, Terima kasih.</strong></h4>
					</div>
				</div>
			</div>
		</div>
		<script src="<?php echo base_url();?>assets/js/jquery.js"></script>
		<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
		<script>
			function modal(){
				$('#myModal').modal();	
			}
			
			$.ajax({
				url: "<?php echo base_url();?>assets/json/content.json",
				dataType: "text",
				success: function (dataTest){
					var json = $.parseJSON(dataTest);
					$.each(json, function (i, jsonObjectList){
						var tgl = jsonObjectList.content[0].created_at;
							tgl = tgl.split(' ');
						var hari  = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', "Jum'at", 'Sabtu'];
						var bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];	
						var tanggal = new Date(tgl).getDate(); var newhari = new Date(tgl).getDay(); var newblan = new Date(tgl).getMonth(); var newthun = new Date(tgl).getYear(); var hari = hari[newhari]; var bulan = bulan[newblan]; var tahun = (newthun < 1000) ? newthun + 1900 : newthun;
						$('#des-1').text(jsonObjectList.content[0].description);
						$('#img-1').attr('src', jsonObjectList.content[0].user_photo);
						$('#name-1').html(jsonObjectList.content[0].fullname+' ('+hari+', '+tanggal+' '+bulan+' '+tahun+' '+tgl[1]+')');
						
						var tgl = jsonObjectList.content[1].created_at;
							tgl = tgl.split(' ');
						var hari  = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', "Jum'at", 'Sabtu'];
						var bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];	
						var tanggal = new Date(tgl).getDate(); var newhari = new Date(tgl).getDay(); var newblan = new Date(tgl).getMonth(); var newthun = new Date(tgl).getYear(); var hari = hari[newhari]; var bulan = bulan[newblan]; var tahun = (newthun < 1000) ? newthun + 1900 : newthun;
						$('#des-2').text(jsonObjectList.content[1].description);
						$('#img-2').attr('src', jsonObjectList.content[1].user_photo);
						$('#name-2').text(jsonObjectList.content[1].fullname+' ('+hari+', '+tanggal+' '+bulan+' '+tahun+' '+tgl[1]+')');
						console.log();
					});
				}
			});
		</script>
	</body>
</html>