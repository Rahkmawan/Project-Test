<?php $this->load->view('header');?>		
	<?php $this->load->view('sidebar');?>			
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<img class="img-responsive" src="<?php echo base_url();?>assets/img/background.jpg" alt="" style="height:360px">
				</div>
				<div class="col-md-8">
					<div class="row">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-md-10">
									<h2 class="page-header" id="name-1"></h2>
								</div>
								<div class="col-md-2">
									<a onclick="modal()" class="btn btn-default" style="margin:40px 0px 20px 0px">Pop up</a>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<img class="img-responsive" id="img-1" alt="" style="margin-right: auto; margin-left: auto;">
						</div>
						<div class="col-md-8">
							<div class="panel panel-default">
								<div class="panel-heading" style="background-color:#12125e">
									<h4 style="color:white"><i class="fa fa-fw fa-check"></i> Deskripsi</h4>
								</div>
								<div class="panel-body">
									<p id="des-1">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, optio corporis quae nulla aspernatur in alias at numquam rerum ea excepturi expedita tenetur assumenda voluptatibus eveniet incidunt dicta nostrum quod?</p>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12">
							<div class="row">
								<div class="col-md-10">
									<h2 class="page-header" id="name-2"></h2>
								</div>
								<div class="col-md-2">
									<a onclick="modal()" class="btn btn-default" style="margin:40px 0px 20px 0px">Pop up</a>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<img class="img-responsive" id="img-2" alt="" style="margin-right: auto; margin-left: auto;">
						</div>
						<div class="col-md-8">
							<div class="panel panel-default">
								<div class="panel-heading" style="background-color:#12125e">
									<h4 style="color:white"><i class="fa fa-fw fa-check"></i> Deskripsi</h4>
								</div>
								<div class="panel-body">
									<p id="des-2">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, optio corporis quae nulla aspernatur in alias at numquam rerum ea excepturi expedita tenetur assumenda voluptatibus eveniet incidunt dicta nostrum quod?</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div><hr />
<?php $this->load->view('footer');?>		